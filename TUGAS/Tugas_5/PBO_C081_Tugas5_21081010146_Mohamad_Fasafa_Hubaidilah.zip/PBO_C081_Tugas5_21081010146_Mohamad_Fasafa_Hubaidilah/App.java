import java.util.Scanner;
/**
 * Hello world!
 */
public final class App {
    private App() {
    }
    /**
     * Says hello to the world.
     * @param args The arguments of the program.
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean cek = false, cek2 = false;
        Object[] arrayObjectBangun = new Object[5];
        // arrayObjectBangun[0] = new Integer(1);
        int jumlahBangun = 0;
        System.out.println("======== Luas & Keliling Bangun Datar ==========");
        do{
            int pilihan = 0;
            int operasi = 0;
            // System.out.print("Pilih Bangun \n1. Kubus\n2. Balok\n3. Tabung\n4. Bola\n5. Limas Segi Empat\nMasukkan Nomor : ");
            try{
                pilihan = jumlahBangun+1;
                switch(pilihan){
                    case 1:
                        do{
                            System.out.print("Pilihan Input \n1. Input Manual(sisi)\n2. Tanpa Input(default: 1)\nMasukkan Nomor : ");
                            try{
                                operasi = Integer.parseInt(sc.nextLine());
                                if(!(operasi >= 1 && operasi <= 2)){
                                    System.out.println("Pilihan Cuma 2");
                                    cek2 = true;
                                }else{ cek2 = false; }
                            }catch(Exception e){
                                System.out.println("Input Salah!");
                                cek2 = true;
                            }
                            
                        }while(cek2);
                        if(operasi == 1){ 
                            System.out.print("Masukkan Sisi : ");
                            int sisi = Integer.parseInt(sc.nextLine());                    
                            arrayObjectBangun[jumlahBangun] = new Kubus(sisi);
                            // kubus.ComputeAndSetVolume();
                            // System.out.println("Hasil ke-"+jumlahBangun+" : " + kubus.GetVolume());
                            
                        }else if(operasi == 2){
                            arrayObjectBangun[jumlahBangun] = new Kubus();
                            // kubus.ComputeAndSetVolume();
                            // System.out.println("Hasil ke-"+jumlahBangun+" : " + kubus.GetVolume());
                            
                        }
                        break;
                    case 2:
                        do{
                            System.out.print("Pilihan Input \n1. Input Manual(panjang [other default: 1])\n2. Input Manual(panjang, lebar [other default: 1])\n3. Input Manual(panjang, lebar, tinggi)\n4. Tanpa Input (default: 1)\nMasukkan Nomor : ");
                            try{
                                operasi = Integer.parseInt(sc.nextLine());
                                if(!(operasi >= 1 && operasi <= 4)){
                                    System.out.println("Pilihan Cuma 4");
                                    cek2 = true;
                                }else{ cek2 = false; }
                            }catch(Exception e){
                                System.out.println("Input Salah!");
                                cek2 = true;
                            }
                        }while(cek2);
                        if(operasi == 1){ 
                            System.out.print("Masukkan Panjang : ");
                            int panjang = Integer.parseInt(sc.nextLine());
                            arrayObjectBangun[jumlahBangun] = new Balok(panjang);
                            // balok.ComputeAndSetVolume();
                            // System.out.println("Hasil ke-"+jumlahBangun+" : " + balok.getVolume());
                            
                        }else if(operasi == 2){
                            System.out.print("Masukkan Panjang : ");
                            int panjang = Integer.parseInt(sc.nextLine());
                            System.out.print("Masukkan Lebar : ");
                            int lebar = Integer.parseInt(sc.nextLine());
                            arrayObjectBangun[jumlahBangun] = new Balok(panjang, lebar);
                            // balok.ComputeAndSetVolume();
                            // System.out.println("Hasil ke-"+jumlahBangun+" : " + balok.getVolume());
                            
                        }else if(operasi == 3){
                            System.out.print("Masukkan Panjang : ");
                            int panjang = Integer.parseInt(sc.nextLine());
                            System.out.print("Masukkan Lebar : ");
                            int lebar = Integer.parseInt(sc.nextLine());
                            System.out.print("Masukkan Tinggi : ");
                            int tinggi = Integer.parseInt(sc.nextLine());
                            arrayObjectBangun[jumlahBangun] = new Balok(panjang, lebar, tinggi);
                            // balok.ComputeAndSetVolume();
                            // System.out.println("Hasil ke-"+jumlahBangun+" : " + balok.getVolume());
                            
                        }else{
                            arrayObjectBangun[jumlahBangun] = new Balok();
                            // balok.ComputeAndSetVolume();
                            // System.out.println("Hasil ke-"+jumlahBangun+" : " + balok.getVolume());
                            
                        }
                        break;
                    case 3:
                        do{
                            System.out.print("Pilihan Input \n1. Input Manual(jari-jari [other default: 1])\n2. Input Manual(jari-jari, tinggi)\n3. Tanpa Input(default: 1)\nMasukkan Nomor : ");
                            try{
                                operasi = Integer.parseInt(sc.nextLine());
                                if(!(operasi >= 1 && operasi <= 3)){
                                    System.out.println("Pilihan Cuma 3");
                                    cek2 = true;
                                }else{ cek2 = false; }
                            }catch(Exception e){
                                System.out.println("Input Salah!");
                                cek2 = true;
                            }
                        }while(cek2);
                        if(operasi == 1){ 
                            System.out.print("Masukkan Jari-jari : ");
                            int jari = Integer.parseInt(sc.nextLine());
                            arrayObjectBangun[jumlahBangun] = new Tabung(jari);
                            // tabung.ComputeAndSetVolume();
                            // System.out.println("Hasil ke-"+jumlahBangun+" : " + tabung.GetVolume());
                            
                        }else if(operasi == 2){
                            System.out.print("Masukkan Jari-jari : ");
                            int jari = Integer.parseInt(sc.nextLine());
                            System.out.print("Masukkan Tinggi : ");
                            int tinggi = Integer.parseInt(sc.nextLine());
                            arrayObjectBangun[jumlahBangun] = new Tabung(jari, tinggi);
                            // tabung.ComputeAndSetVolume();
                            // System.out.println("Hasil ke-"+jumlahBangun+" : " + tabung.GetVolume());
                            
                        }else{
                            arrayObjectBangun[jumlahBangun] = new Tabung();
                            // tabung.ComputeAndSetVolume();
                            // System.out.println("Hasil ke-"+jumlahBangun+" : " + tabung.GetVolume());
                            
                        }
                        break;
                    case 4:
                        do{
                            System.out.print("Pilih Input \n1. Input Manual(jari-jari)\n2. Tanpa Input(default: 1)\nMasukkan Nomor : ");
                            try{
                                operasi = Integer.parseInt(sc.nextLine());
                                if(!(operasi >= 1 && operasi <= 2)){
                                    System.out.println("Pilihan Cuma 2");
                                    cek2 = true;
                                }else{ cek2 = false; }
                            }catch(Exception e){
                                System.out.println("Input Salah!");
                                cek2 = true;
                            }
                        }while(cek2);
                        if(operasi == 1){ 
                            System.out.print("Masukkan Jari-jari : ");
                            int jari = Integer.parseInt(sc.nextLine());
                            arrayObjectBangun[jumlahBangun] = new Bola(jari);
                            // bola.ComputeAndSetVolume();
                            // System.out.println("Hasil ke-"+jumlahBangun+" : " + bola.GetVolume());
                            
                        }else if(operasi == 2){
                            arrayObjectBangun[jumlahBangun] = new Bola();
                            // bola.ComputeAndSetVolume();
                            // System.out.println("Hasil ke-"+jumlahBangun+" : " + bola.GetVolume());
                            
                        }
                        break;
                    case 5:
                    do{
                        System.out.print("Pilihan Input \n1. Input Manual(sisi [other default: 1])\n2. Input Manual(sisi, tinggi)\n3. Tanpa Input(default: 1)\nMasukkan Nomor : ");
                        try{
                            operasi = Integer.parseInt(sc.nextLine());
                            if(!(operasi >= 1 && operasi <= 3)){
                                System.out.println("Pilihan Cuma 3");
                                cek2 = true;
                            }else{ cek2 = false; }
                        }catch(Exception e){
                            System.out.println("Input Salah!");
                            cek2 = true;
                        }
                    }while(cek2);
                    if(operasi == 1){ 
                        System.out.print("Masukkan Sisi : ");
                        int sisi = Integer.parseInt(sc.nextLine());
                        arrayObjectBangun[jumlahBangun] = new LimasSegiEmpat(sisi);
                        // limasSegiEmpat.ComputeAndSetVolume();
                        // System.out.println("Hasil ke-"+jumlahBangun+" : " + limasSegiEmpat.GetVolume());
                    }else if(operasi == 2){
                        System.out.print("Masukkan sisi : ");
                        int sisi = Integer.parseInt(sc.nextLine());
                        System.out.print("Masukkan Tinggi : ");
                        int tinggi = Integer.parseInt(sc.nextLine());
                        arrayObjectBangun[jumlahBangun] = new LimasSegiEmpat(sisi, tinggi);
                        // limasSegiEmpat.ComputeAndSetVolume();
                        // System.out.println("Hasil ke-"+jumlahBangun+" : " + limasSegiEmpat.GetVolume());
                    }else{
                        arrayObjectBangun[jumlahBangun] = new LimasSegiEmpat();
                        // limasSegiEmpat.ComputeAndSetVolume();
                        // System.out.println("Hasil ke-"+jumlahBangun+" : " + limasSegiEmpat.GetVolume());
                    }
                        break;
                    default:
                        System.out.println("Pilihan Cuma 5");
                        cek = true;
                        break;
                }
                jumlahBangun++;
            }catch(Exception e){
                System.out.println("Input Salah!");
                cek = true;
            }
        }while(jumlahBangun < 5);
        sc.close();
        // System.out.println("========= Terima Kasih ===========");
        
        
        // Tabung tabung = (Tabung)arrayObjectBangun[2];
        // Bola bola = (Bola)arrayObjectBangun[3];
        // LimasSegiEmpat limasSegiEmpat = (LimasSegiEmpat)arrayObjectBangun[4];
        int i = 1;
        double totalVolume = 0;
        for(Object bangun: arrayObjectBangun){
            if(i == 1){
                Kubus kubus = (Kubus)bangun;
                kubus.ComputeAndSetVolume();
                totalVolume += kubus.GetVolume();
            }else if(i == 2){
                Balok balok = (Balok)bangun;
                balok.ComputeAndSetVolume();
                totalVolume += balok.getVolume();
            }else if(i == 3){
                Tabung tabung = (Tabung)bangun;
                tabung.ComputeAndSetVolume();
                totalVolume += tabung.GetVolume();
            }else if(i == 4){
                Bola bola = (Bola)bangun;
                bola.ComputeAndSetVolume();
                totalVolume += bola.GetVolume();
            }else if(i == 5){
                LimasSegiEmpat limasSegiEmpat = (LimasSegiEmpat)bangun;
                limasSegiEmpat.ComputeAndSetVolume();
                totalVolume += limasSegiEmpat.GetVolume();
            }
            i++;
        }
        double rata = totalVolume / 5;
        System.out.println("Rata-rata Volume : "+ rata);
    }
}
